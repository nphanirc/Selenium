import java.sql.SQLException; 
import java.util.List; 
  
public class AuditorBO extends UserBO{ 
InvoiceDAO invoiceDAO = new InvoiceDAO(); 
@Override 
List<Invoice> listInvoice() throws InsufficientPrivilegeException, ClassNotFoundException, SQLException { 
// TODO Auto-generated method stub 
  
return invoiceDAO.getAllInvoiceList(); 
//return invoice except paid 
} 
  
@Override 
Integer createInvoice(Invoice invoice) throws InsufficientPrivilegeException { 
// TODO Auto-generated method stub 
throw new InsufficientPrivilegeException("Permission Denied"); 
} 
  
  
}