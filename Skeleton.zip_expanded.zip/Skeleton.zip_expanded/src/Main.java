import java.io.BufferedReader; 
import java.io.InputStreamReader; 
import java.text.SimpleDateFormat; 
import java.util.ArrayList; 
import java.util.Iterator; 
import java.util.List; 
  
public class Main { 
  
    public static void main(String[] args) throws Exception { 
User user; 
UserBO userBO; 
String status; 
Boolean logout; 
Invoice invoice; 
Integer statusId; 
Integer invoiceId; 
String newLine = "\n"; 
String invoiceDetails; 
List<Invoice> invoiceList; 
StringBuilder mainMenu = new StringBuilder(); 
StringBuilder userMenu = new StringBuilder(); 
StringBuilder auditorMenu = new StringBuilder(); 
SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); 
BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); 
mainMenu.append("1. Login").append(newLine).append("2. Exit") 
.append(newLine).append("Enter the choice:"); 
userMenu.append("1. Create invoice").append(newLine) 
.append("2. List invoice").append(newLine) 
.append("3. Logout").append(newLine) 
.append("Enter the choice:"); 
while (true) { 
System.out.println(mainMenu.toString()); 
int choice = new Integer(br.readLine()); 
switch (choice) { 
case 1: 
System.out.println("Enter the username:"); 
String userName = br.readLine(); 
System.out.println("Enter the password:"); 
String password = br.readLine(); 
User validatedUser = UserBO.validateUser(userName, password); 
if (validatedUser!=null) { 
logout = false; 
//fill code here. 
//List<User> users = findRole(validatedUser).users; 
String role = validatedUser.getRole(); 
while (true) { 
System.out.println(userMenu.toString()); 
int userChoice = new Integer(br.readLine()); 
switch (userChoice) { 
case 1: 
try { 
System.out.println("Enter the invoice detail:"); 
invoiceDetails = br.readLine(); 
//fill code here. 
String[] splitted = invoiceDetails.split(","); 
int id = 0; 
if(role.equals("Clerk")){ 
ClerkBO clerkBO = new ClerkBO(); 
id = clerkBO.createInvoice(new Invoice(splitted[0],Integer.parseInt(splitted[1]),sdf.parse(splitted[2]),validatedUser)); 
} 
if(role.equals("Auditor")){ 
AuditorBO auditorBO = new AuditorBO(); 
id = auditorBO.createInvoice(new Invoice(splitted[0],Integer.parseInt(splitted[1]),sdf.parse(splitted[2]),validatedUser)); 
} 
//fill code here. 
if(id!=0){ 
System.out.println("Invoice created successfully"); 
} 
} catch (Exception e) { 
System.out.println(e.toString()); 
} 
break; 
case 2: 
try { 
InvoiceDAO invoiceDAO = new InvoiceDAO(); 
List<Invoice> invoiceList1 = new ArrayList<Invoice>();; 
//fill code here. 
/*System.out.println("Enter the id to update the status:"); 
invoiceId = new Integer(br.readLine()); 
Boolean state = false; 
Invoice reqinv = null; 
while(itr.hasNext()){ 
Invoice inv = itr.next(); 
if(inv.getId()==invoiceId){ 
reqinv = inv; 
} 
} 
if (reqinv!=null) { 
System.out.println(auditorMenu.toString()); 
System.out.println("Enter the status number:"); 
statusId = new Integer(br.readLine()); 
String statusName; 
if(statusId==1) 
statusName = auditorList.get(0); 
else 
statusName = auditorList.get(1); 
  
*/ 
if(role.equals("Clerk")){ 
ClerkBO clerkBO = new ClerkBO();  
invoiceList1 = clerkBO.listInvoice(); 
} 
if(role.equals("Auditor")){ 
AuditorBO auditorBO = new AuditorBO(); 
invoiceList1 = auditorBO.listInvoice(); 
} 
if (!invoiceList1.isEmpty()) { 
System.out.format("%-5s %-15s %-10s %-15s %-15s %s\n","Id", "Invoice number","Amount", "Status","Created by", "Created on"); 
//fill code here. 
Iterator<Invoice> itr = invoiceList1.iterator(); 
while(itr.hasNext()){ 
Invoice inv = itr.next(); 
System.out.format( 
"%-5s %-15s %-10s %-15s %-15s %s\n",inv.getId(), 
inv.getInvoiceNumber(), inv.getAmount(), 
inv.getStatus(), inv.getCreatedBy().getUserName(), 
inv.getCreatedDate()); 
} 
} 
} 
catch (Exception e) { 
System.out.println(e.toString()); 
} 
break; 
case 3: 
logout = true; 
break; 
} 
if (logout) 
break; 
} 
} else 
System.out.println("Invalid username or password"); 
break; 
case 2: 
System.exit(0); 
} 
} 
} 
  
public static UserBO findRole(User user) { 
String role = user.getRole(); 
if (role.equalsIgnoreCase("clerk")) 
//fill code here. 
if (role.equalsIgnoreCase("auditor")) 
//fill code here. 
return null; 
return null; 
} 
}  
