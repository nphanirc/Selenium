import os
import pdfkit
import sys

options = {
    'page-size': 'A3',
    'margin-top': '0.17in',
    'margin-right': '0.17in',
    'margin-bottom': '0.17in',
    'margin-left': '0.17in',
    'dpi':'225',
}

k=[]
fn=[]
for r,d,f in os.walk(sys.argv[1]):
			
                for file in f:
                                if ".html" in file:
                                                par = os.path.dirname(r)
                                                print(par)
                                                fol=par.rfind('\\')
                                                tc = par[fol+1:]
                                                if "Summary.html" in file:
                                                                k.append(os.path.join(r, file))
                                                                fn.append("Summary - "+tc)
                                                else:
                                                                k.append(os.path.join(r, file))
                                                                fn.append(file[:len(file)-5])
for i in range(0,len(k)):
    filename=fn[i]
    print(k[i])
    print(filename)    
    
    pdfkit.from_file(k[i],str(sys.argv[2])+"\\"+str(filename)+".pdf",options = options)

